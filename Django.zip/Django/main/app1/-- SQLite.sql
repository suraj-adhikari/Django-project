-- SQLite
SELECT id, ename , joining_date , creaated_date
FROM app1_employee;