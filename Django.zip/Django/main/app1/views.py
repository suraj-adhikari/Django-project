from cgitb import text
from multiprocessing import context
from unicodedata import name
from django import template
from django.shortcuts import render
from django.template import loader
from .forms import Employeeform
# Create your views here.
from django.http import HttpResponse

def showme(request):
    text= """<h1> welcome to my app!</h1>"""
    return HttpResponse(text)


def index(request):
    template = loader.get_template('index.html')
    name = {
        'name':'Suraj'
    }
    return HttpResponse(template.render(name))

def home(request):
    context={}
    context["name"]="Mark"
    context['myform']=Employeeform
    return render(request,"index.html",context)