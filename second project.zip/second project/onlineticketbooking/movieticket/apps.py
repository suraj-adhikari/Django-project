from django.apps import AppConfig


class MovieticketConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movieticket'
